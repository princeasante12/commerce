const router = require('express').Router()
const authController = require('../controllers/auth')
const {body} = require('express-validator')

router.get('/login', authController.getLogin)
router.get('/signup', authController.getSignup)

router.post("/login", [body('email').isEmail().trim(), body('password').isLength({ min : 6 })],authController.postLogin)
router.post("/signup", [body('email').isEmail().trim(), body('password').isLength({ min : 6 })],authController.postSignup)

router.get('/logout', authController.getLogout)
module.exports = router