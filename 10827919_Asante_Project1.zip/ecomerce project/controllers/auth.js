const User = require("../models/user")
const Product = require("../models/product")
const bcrypt = require('bcryptjs')

exports.getLogin = (req, res, next) => {
    res.render("auth/login", {
        pageTitle : 'Login page',
        oldCredentials : {
            email : '',
            password : ''
        },
        path : '/login'
    })
}
exports.getSignup = (req, res, next) => {
    res.render("auth/signup", {
        pageTitle : 'Sign up Page',
        path : '/signup',
        oldCredentials : {
            email : '',
            password : ''
        }
    })
}

exports.postLogin = async (req, res, next) => {
    const email = req.body.email
    const password = req.body.password

    const userExists = await User.findOne({ email : email })
    if(!userExists){
        return res.render('auth/login', {
            oldCredentials : {
                email : email,
                password : password
            },
            errorMessage : "User doesn't exist"
        })
    }
    const passwordDoesMatch = await bcrypt.compare(password, userExists.password)
    if(!passwordDoesMatch){
        return res.render('auth/login', {
            pageTitle : 'Login',
            oldCredentials : {
                email : email,
                password : password
            },
            errorMessage : "Password does not match"
        })
    }
    req.session.isAuth = true
    req.session.userId = userExists._id
    req.session.save((error) => {
        if(error){
            next(error)
        }
    })
    return res.redirect('/')

}

exports.postSignup = async (req, res, next) => {
    const email = req.body.email
    const password = req.body.password

    const userExists = await User.findOne({ email : email })
    if(userExists){
        return res.render('auth/login', {
            oldCredentials : {
                email : email,
                password : password
            },
            errorMessage : "User already exists"
        })
    }

    const encryptedPassword = await bcrypt.hash(password, 12)

    const newUser = new User({ email : email, password : encryptedPassword })
    await newUser.save()
    return res.redirect('/login')
}

exports.getLogout = (req, res, next) => {
    req.session.destroy((error) => {
        if(error){
            console.log(error)
            next(error)
        }
    })
    res.redirect('/login')
}